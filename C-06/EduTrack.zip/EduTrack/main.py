# ==========================================================
# IMPORTS
# ==========================================================

# Allows the program to save and load information using JSON files
import json

# Allows the program to create folders and check files
import os

# Used for checking username formats
import re


# Used to create the graphical user interface
import tkinter as tk

# Provides advanced Tkinter widgets such as tables and dropdowns
from tkinter import ttk, messagebox

# ==========================================================
# ACCOUNT STORAGE SETUP
# ==========================================================

# Creates the accounts folder if it does not already exist
# This folder stores all user profiles
if not os.path.exists("accounts"):

    os.mkdir("accounts")

# ==========================================================
# APPLICATION WINDOW SETUP
# ==========================================================

# Creates the main application window
window = tk.Tk()

# Sets the application title shown at the top
window.title(
    "EduTrack"
)
# Sets the default window size
window.geometry(
    "1100x700"
)
# Sets the background colour
window.configure(
    bg="#F4F6FA"
)

# ==========================================================
# THEME COLOURS
# ==========================================================
# Stores all application colours in one place
# This makes changing the design easier later

COLORS = {

    # Main dark blue colour used for branding
    "primary": "#1F4E79",
    # Secondary blue used for buttons
    "secondary": "#2E75B6",
    # Main application background
    "background": "#F4F6FA",
    # White cards and panels
    "white": "#FFFFFF",
    # Main text colour
    "dark": "#1E293B",
    # Grey text colour
    "grey": "#64748B",
    # Used for logout and warnings
    "danger": "#DC2626",
    # Used for late work
    "warning": "#F59E0B",
    # Used for completed work
    "success": "#16A34A"
    
}

# ==========================================================
# FONT SETTINGS
# ==========================================================

# Large titles used for page headings
FONT_TITLE = (
    "Segoe UI",
    24,
    "bold"
)

# Smaller headings
FONT_HEADER = (
    "Segoe UI",
    16,
    "bold"
)

# Normal application text
FONT_NORMAL = (
    "Segoe UI",
    11
)

# ==========================================================
# GLOBAL APPLICATION DATA
# ==========================================================

# Stores all students currently loaded
students = []

# Stores the currently logged-in username
current_user = ""

# ==========================================================
# AVAILABLE CLASSES
# ==========================================================

# Used in class selection dropdown menus
CLASSES = [

    "English",

    "Maths",

    "Science",

    "Drama",

    "Humanities",

    "Digi-Tech",

    "Japanese",

    "Art",

    "Agriculture"

]

# ==========================================================
# AVAILABLE WORK STATUSES
# ==========================================================
# Used when adding or editing student records
STATUSES = [

    "Missing",

    "Late",

    "Submitted"

]
# ==========================================================
# TKINTER STYLE SETTINGS
# ==========================================================
# Creates a style manager for ttk widgets
style = ttk.Style()

# Uses the clam theme for cleaner modern widgets
style.theme_use(
    "clam"
)
# ==========================================================
# TABLE DESIGN
# ==========================================================

# Controls the appearance of student tables

style.configure(

    "Treeview",

    background=COLORS["white"],

    foreground=COLORS["dark"],

    rowheight=35,

    fieldbackground=COLORS["white"],

    font=FONT_NORMAL

)



# Controls table heading appearance

style.configure(

    "Treeview.Heading",

    font=(

        "Segoe UI",

        11,

        "bold"

    )

)



# ==========================================================
# WINDOW MANAGEMENT
# ==========================================================


def clear_window():

    """
    Removes all widgets currently displayed
    in the application window.

    Used when changing between pages.
    """


    # Loops through every widget
    for widget in window.winfo_children():


        # Deletes the widget
        widget.destroy()





# ==========================================================
# ACCOUNT DATA MANAGEMENT
# ==========================================================


def save_data():

    """
    Saves the current student's information
    into the logged-in user's JSON file.
    """


    # Stops if nobody is logged in
    if current_user == "":

        return



    # Creates the account file location
    filename = (

        f"accounts/{current_user}.json"

    )



    # Stops if the account file does not exist
    if not os.path.exists(filename):

        return



    # Opens the account file
    with open(

        filename,

        "r",

        encoding="utf-8"

    ) as file:


        data = json.load(file)



    # Updates student information
    data["students"] = students



    # Saves updated information
    with open(

        filename,

        "w",

        encoding="utf-8"

    ) as file:


        json.dump(

            data,

            file,

            indent=4

        )





# ==========================================================
# LOAD ACCOUNT DATA
# ==========================================================


def load_account(filename):

    """
    Loads an account file and returns
    the stored information.
    """


    try:


        # Opens JSON file
        with open(

            filename,

            "r",

            encoding="utf-8"

        ) as file:


            return json.load(file)



    except:


        # Displays error if loading fails
        messagebox.showerror(

            "Error",

            "Unable to load account."

        )


        return None

# ==========================================================
# ACCOUNT CREATION
# ==========================================================


def create_account(username, password):

    """
    Creates a new teacher account.

    Each account is stored as a JSON file
    containing:
    - Password
    - Student records
    """


    # Checks that both fields have information
    if username == "" or password == "":

        messagebox.showwarning(

            "Missing Details",

            "Enter a username and password."

        )

        return



    # Checks username only contains safe characters
    if not re.fullmatch(

        r"[A-Za-z0-9_]+",

        username

    ):


        messagebox.showwarning(

            "Invalid Username",

            "Only letters, numbers and underscores allowed."

        )

        return



    # Creates file location
    filename = (

        f"accounts/{username}.json"

    )



    # Prevents duplicate accounts
    if os.path.exists(filename):

        messagebox.showerror(

            "Account Exists",

            "Username already exists."

        )

        return



    # Information saved into new account
    data = {

        "password": password,

        "students": []

    }



    # Creates the account file
    with open(

        filename,

        "w",

        encoding="utf-8"

    ) as file:


        json.dump(

            data,

            file,

            indent=4

        )



    messagebox.showinfo(

        "Success",

        "Profile created."

    )



    # Returns user to login page
    login_screen()





# ==========================================================
# LOGIN SYSTEM
# ==========================================================


def login_user(username, password):

    """
    Checks login details and loads
    the user's saved student data.
    """


    global current_user



    # Finds account file
    filename = (

        f"accounts/{username}.json"

    )



    # Checks account exists
    if not os.path.exists(filename):

        messagebox.showerror(

            "Login Failed",

            "Account does not exist."

        )

        return



    # Loads account information
    data = load_account(filename)



    # Checks password
    if data["password"] != password:

        messagebox.showerror(

            "Login Failed",

            "Incorrect password."

        )

        return



    # Saves current username
    current_user = username



    # Removes old student data
    students.clear()



    # Loads saved students
    students.extend(

        data["students"]

    )


    # Opens student page
    show_student_list()





# ==========================================================
# LOGIN PAGE
# ==========================================================


def login_screen():

    """
    Creates the EduTrack login page.
    """


    # Removes previous widgets
    clear_window()



    # Background container
    background = tk.Frame(

        window,

        bg=COLORS["background"]

    )


    background.pack(

        fill="both",

        expand=True

    )



    # EduTrack title
    title = tk.Label(

        background,

        text="EduTrack",

        font=FONT_TITLE,

        fg=COLORS["primary"],

        bg=COLORS["background"]

    )


    title.pack(

        pady=50

    )



    # White login card
    card = tk.Frame(

        background,

        bg=COLORS["white"],

        padx=40,

        pady=40,

        relief="ridge",

        bd=1

    )


    card.pack()



    # Username label
    tk.Label(

        card,

        text="Username",

        font=FONT_NORMAL,

        bg=COLORS["white"]

    ).pack(

        anchor="w"

    )



    # Username input
    username_entry = tk.Entry(

        card,

        width=35,

        font=FONT_NORMAL

    )


    username_entry.pack(

        pady=5

    )



    # Password label
    tk.Label(

        card,

        text="Password",

        font=FONT_NORMAL,

        bg=COLORS["white"]

    ).pack(

        anchor="w"

    )



    # Password input
    password_entry = tk.Entry(

        card,

        width=35,

        show="*",

        font=FONT_NORMAL

    )


    password_entry.pack(

        pady=5

    )



    # Login button
    tk.Button(

        card,

        text="Sign In",

        width=25,

        bg=COLORS["primary"],

        fg="white",

        font=FONT_NORMAL,

        command=lambda:

        login_user(

            username_entry.get(),

            password_entry.get()

        )

    ).pack(

        pady=15

    )



    # Create account button
    tk.Button(

        card,

        text="Create New Profile",

        width=25,

        font=FONT_NORMAL,

        command=lambda:

        create_account(

            username_entry.get(),

            password_entry.get()

        )

    ).pack()





# ==========================================================
# MAIN DASHBOARD LAYOUT
# ==========================================================


def create_dashboard():

    """
    Creates the main application layout.

    Includes:
    - Sidebar navigation
    - Main content area
    """


    clear_window()



    global content_frame



    # ======================================================
    # SIDEBAR
    # ======================================================


    sidebar = tk.Frame(

        window,

        bg=COLORS["primary"],

        width=220

    )


    sidebar.pack(

        side="left",

        fill="y"

    )



    # EduTrack logo/title
    tk.Label(

        sidebar,

        text="EduTrack",

        font=FONT_TITLE,

        fg="white",

        bg=COLORS["primary"]

    ).pack(

        pady=30

    )



    # Navigation buttons
    navigation_buttons = [

        ("Students", show_student_list),

        ("Profile", show_profile),

        ("Reminders", show_reminders),

        ("Reports", show_report)

    ]



    # Creates navigation buttons
    for text, command in navigation_buttons:


        tk.Button(

            sidebar,

            text=text,

            width=20,

            height=2,

            bg=COLORS["secondary"],

            fg="white",

            relief="flat",

            font=FONT_NORMAL,

            command=command

        ).pack(

            pady=8,

            padx=15

        )



    # ======================================================
    # LOGOUT AREA
    # ======================================================


    # Creates empty space to push logout down
    spacer = tk.Frame(

        sidebar,

        bg=COLORS["primary"]

    )


    spacer.pack(

        expand=True

    )



    # Separate logout button
    tk.Button(

        sidebar,

        text="Logout",

        width=14,

        height=1,

        bg=COLORS["danger"],

        fg="white",

        activebackground="#991B1B",

        activeforeground="white",

        relief="flat",

        font=(

            "Segoe UI",

            10,

            "bold"

        ),

        command=logout

    ).pack(

        pady=25,

        padx=15

    )



    # ======================================================
    # MAIN CONTENT AREA
    # ======================================================


    content_frame = tk.Frame(

        window,

        bg=COLORS["background"]

    )


    content_frame.pack(

        side="right",

        fill="both",

        expand=True

    )





# ==========================================================
# LOGOUT FUNCTION
# ==========================================================


def logout():

    """
    Logs the user out.

    Saves data before returning
    to the login screen.
    """


    global current_user



    # Saves current records
    save_data()



    # Clears student information
    students.clear()



    # Removes current user
    current_user = ""



    # Returns to login page
    login_screen()
    
# ==========================================================
# STUDENT MANAGEMENT PAGE
# ==========================================================


def show_student_list():

    """
    Displays the main student management page.

    Teachers can:
    - View students
    - Search students
    - Add students
    - Edit students
    - Remove students
    """


    # Creates the dashboard layout
    create_dashboard()



    # Clears any old page content
    for widget in content_frame.winfo_children():

        widget.destroy()



    # ======================================================
    # PAGE TITLE
    # ======================================================


    tk.Label(

        content_frame,

        text="Student Management",

        font=FONT_TITLE,

        bg=COLORS["background"],

        fg=COLORS["primary"]

    ).pack(

        pady=20

    )



    # ======================================================
    # SEARCH AREA
    # ======================================================


    # Holds search controls
    search_frame = tk.Frame(

        content_frame,

        bg=COLORS["background"]

    )


    search_frame.pack()



    # Search input box
    search_entry = tk.Entry(

        search_frame,

        width=40,

        font=FONT_NORMAL

    )


    search_entry.pack(

        side="left",

        padx=5

    )



    # ======================================================
    # STUDENT TABLE
    # ======================================================


    # Columns displayed in table
    columns = (

        "Name",

        "Student ID",

        "Class",

        "Status",

        "Record"

    )



    # Creates student table
    table = ttk.Treeview(

        content_frame,

        columns=columns,

        show="headings"

    )



    # Creates each table heading
    for column in columns:


        table.heading(

            column,

            text=column

        )


        table.column(

            column,

            width=140

        )



    # Hides internal record ID column
    table.column(

        "Record",

        width=0,

        stretch=False

    )



    # Displays table
    table.pack(

        fill="both",

        expand=True,

        padx=20,

        pady=20

    )



    # ======================================================
    # STATUS COLOURS
    # ======================================================


    # Missing work appears red
    table.tag_configure(

        "Missing",

        foreground=COLORS["danger"]

    )


    # Late work appears orange
    table.tag_configure(

        "Late",

        foreground=COLORS["warning"]

    )


    # Submitted work appears green
    table.tag_configure(

        "Submitted",

        foreground=COLORS["success"]

    )



    # ======================================================
    # REFRESH TABLE
    # ======================================================


    def refresh(data):

        """
        Updates the table with current data.
        """


        # Removes existing rows
        for item in table.get_children():

            table.delete(item)



        # Adds students back into table
        for student in data:


            table.insert(

                "",

                "end",

                values=(

                    student["Name"],

                    student["ID"],

                    student["Class"],

                    student["Status"],

                    student["RecordID"]

                ),

                tags=(

                    student["Status"],

                )

            )



    # Loads existing students
    refresh(students)



    # ======================================================
    # SEARCH FUNCTION
    # ======================================================


    def search():

        """
        Searches students by:
        - Name
        - Student ID
        """


        search_text = search_entry.get().lower()



        results = []



        for student in students:


            if (

                search_text in student["Name"].lower()

                or search_text in student["ID"].lower()

            ):

                results.append(student)



        refresh(results)



    # Search button
    tk.Button(

        search_frame,

        text="Search",

        command=search

    ).pack(

        side="left"

    )



    # Clear search button
    tk.Button(

        search_frame,

        text="Clear",

        command=lambda:

        refresh(students)

    ).pack(

        side="left",

        padx=5

    )



    # ======================================================
    # STUDENT BUTTONS
    # ======================================================


    button_frame = tk.Frame(

        content_frame,

        bg=COLORS["background"]

    )


    button_frame.pack()



    # Add student button
    tk.Button(

        button_frame,

        text="Add Student",

        width=18,

        command=lambda:

        add_student_window(refresh)

    ).grid(

        row=0,

        column=0,

        padx=5

    )



    # Edit student button
    tk.Button(

        button_frame,

        text="Edit Student",

        width=18,

        command=lambda:

        edit_student_window(

            table,

            refresh

        )

    ).grid(

        row=0,

        column=1,

        padx=5

    )



    # Remove student button
    tk.Button(

        button_frame,

        text="Remove Student",

        width=18,

        command=lambda:

        remove_student(

            table,

            refresh

        )

    ).grid(

        row=0,

        column=2,

        padx=5

    )





# ==========================================================
# ADD STUDENT WINDOW
# ==========================================================


def add_student_window(refresh):

    """
    Opens a window allowing teachers
    to create a new student record.
    """


    # Creates popup window
    popup = tk.Toplevel(window)


    popup.title(

        "Add Student"

    )


    popup.geometry(

        "350x450"

    )



    # Stores input boxes
    entries = {}



    # Text fields required
    fields = [

        "Name",

        "ID"

    ]



    # Creates name and ID inputs
    for field in fields:


        tk.Label(

            popup,

            text=field

        ).pack()



        entry = tk.Entry(

            popup

        )


        entry.pack()



        entries[field] = entry



    # Class selector
    tk.Label(

        popup,

        text="Class"

    ).pack()



    class_box = ttk.Combobox(

        popup,

        values=CLASSES,

        state="readonly"

    )


    class_box.pack()



    # Status selector
    tk.Label(

        popup,

        text="Status"

    ).pack()



    status_box = ttk.Combobox(

        popup,

        values=STATUSES,

        state="readonly"

    )


    status_box.pack()





    def save():

        """
        Saves the new student record.
        """


        students.append(

            {

                "RecordID":

                len(students) + 1,


                "Name":

                entries["Name"].get(),


                "ID":

                entries["ID"].get(),


                "Class":

                class_box.get(),


                "Status":

                status_box.get()

            }

        )



        # Saves changes
        save_data()



        # Updates table
        refresh(students)



        # Closes popup
        popup.destroy()



    # Save button
    tk.Button(

        popup,

        text="Save",

        command=save

    ).pack(

        pady=20

    )
    
# ==========================================================
# REMOVE STUDENT
# ==========================================================


def remove_student(table, refresh):

    """
    Removes a selected student from the system.
    """


    # Gets currently selected table row
    selected = table.focus()



    # Stops if no student is selected
    if not selected:

        messagebox.showwarning(

            "No Selection",

            "Please select a student first."

        )

        return



    # Gets hidden Record ID
    record = table.item(selected)["values"][4]



    # Searches through students
    for student in students:


        if student["RecordID"] == record:


            # Removes student
            students.remove(student)


            break



    # Saves updated information
    save_data()



    # Refreshes table
    refresh(students)





# ==========================================================
# EDIT STUDENT WINDOW
# ==========================================================


def edit_student_window(table, refresh):

    """
    Allows teachers to edit an existing student.

    Editable information:
    - Name
    - Student ID
    - Class
    - Status
    """


    # Gets selected student
    selected = table.focus()



    # Stops if nothing selected
    if not selected:

        messagebox.showwarning(

            "No Selection",

            "Please select a student first."

        )

        return



    # Finds selected student's record ID
    record = table.item(selected)["values"][4]



    # Finds matching student
    for student in students:


        if student["RecordID"] == record:



            # Creates editing window
            popup = tk.Toplevel(window)



            popup.title(

                "Edit Student"

            )



            popup.geometry(

                "350x400"

            )



            # ==================================================
            # NAME FIELD
            # ==================================================


            tk.Label(

                popup,

                text="Name"

            ).pack()



            name_entry = tk.Entry(

                popup

            )


            name_entry.insert(

                0,

                student["Name"]

            )


            name_entry.pack()



            # ==================================================
            # STUDENT ID FIELD
            # ==================================================


            tk.Label(

                popup,

                text="Student ID"

            ).pack()



            id_entry = tk.Entry(

                popup

            )


            id_entry.insert(

                0,

                student["ID"]

            )


            id_entry.pack()



            # ==================================================
            # CLASS FIELD
            # ==================================================


            tk.Label(

                popup,

                text="Class"

            ).pack()



            class_box = ttk.Combobox(

                popup,

                values=CLASSES,

                state="readonly"

            )


            class_box.set(

                student["Class"]

            )


            class_box.pack()



            # ==================================================
            # STATUS FIELD
            # ==================================================


            tk.Label(

                popup,

                text="Status"

            ).pack()



            status_box = ttk.Combobox(

                popup,

                values=STATUSES,

                state="readonly"

            )


            status_box.set(

                student["Status"]

            )


            status_box.pack()





            def save():

                """
                Saves edited information.
                """


                # Updates student details
                student["Name"] = name_entry.get()


                student["ID"] = id_entry.get()


                student["Class"] = class_box.get()


                student["Status"] = status_box.get()



                # Saves changes
                save_data()



                # Updates table
                refresh(students)



                # Closes window
                popup.destroy()




            # Save button
            tk.Button(

                popup,

                text="Save Changes",

                command=save

            ).pack(

                pady=20

            )



            break





# ==========================================================
# PROFILE PAGE
# ==========================================================


def show_profile():

    """
    Displays information about the
    current teacher account.
    """


    create_dashboard()



    # Clears previous page
    for widget in content_frame.winfo_children():

        widget.destroy()



    # Page heading
    tk.Label(

        content_frame,

        text="User Profile",

        font=FONT_TITLE,

        bg=COLORS["background"],

        fg=COLORS["primary"]

    ).pack(

        pady=20

    )



    # Profile information card
    card = tk.Frame(

        content_frame,

        bg=COLORS["white"],

        bd=2,

        relief="ridge"

    )


    card.pack(

        padx=50,

        pady=20,

        fill="x"

    )



    # Counts different student statuses
    missing = 0

    late = 0

    submitted = 0



    for student in students:


        if student["Status"] == "Missing":

            missing += 1



        elif student["Status"] == "Late":

            late += 1



        else:

            submitted += 1





    # Information displayed
    information = [

        f"Username: {current_user}",

        f"Students Managed: {len(students)}",

        f"Missing Work: {missing}",

        f"Late Work: {late}",

        f"Submitted Work: {submitted}"

    ]



    # Creates labels
    for item in information:


        tk.Label(

            card,

            text=item,

            font=FONT_HEADER,

            bg=COLORS["white"],

            fg=COLORS["dark"]

        ).pack(

            pady=10

        )





# ==========================================================
# REMINDERS PAGE
# ==========================================================


def show_reminders():

    """
    Displays students who still have
    missing work.
    """


    create_dashboard()



    # Clears old content
    for widget in content_frame.winfo_children():

        widget.destroy()



    # Page title
    tk.Label(

        content_frame,

        text="Missing Work Reminders",

        font=FONT_TITLE,

        bg=COLORS["background"],

        fg=COLORS["danger"]

    ).pack(

        pady=20

    )



    # Finds missing students
    missing_students = [

        student

        for student in students

        if student["Status"] == "Missing"

    ]



    # Shows amount requiring attention
    tk.Label(

        content_frame,

        text=f"{len(missing_students)} student(s) require attention",

        font=FONT_HEADER,

        bg=COLORS["background"]

    ).pack()



    # Creates reminder table
    table = ttk.Treeview(

        content_frame,

        columns=(

            "Name",

            "Class",

            "Status"

        ),

        show="headings"

    )



    # Adds columns
    for column in (

        "Name",

        "Class",

        "Status"

    ):


        table.heading(

            column,

            text=column

        )



        table.column(

            column,

            width=200

        )



    table.pack(

        expand=True,

        fill="both",

        padx=30,

        pady=30

    )



    # Adds missing students
    for student in missing_students:


        table.insert(

            "",

            "end",

            values=(

                student["Name"],

                student["Class"],

                student["Status"]

            )

        )
# ==========================================================
# REPORT DASHBOARD
# ==========================================================


def show_report():

    """
    Displays a summary report of student work.

    Shows:
    - Total students
    - Missing work count
    - Late work count
    - Submitted work count
    - Students requiring attention
    """


    # Creates dashboard layout
    create_dashboard()



    # Removes old page content
    for widget in content_frame.winfo_children():

        widget.destroy()



    # ======================================================
    # PAGE TITLE
    # ======================================================


    tk.Label(

        content_frame,

        text="Reports Dashboard",

        font=FONT_TITLE,

        bg=COLORS["background"],

        fg=COLORS["primary"]

    ).pack(

        pady=20

    )



    # ======================================================
    # COUNT STUDENT STATUSES
    # ======================================================


    missing = 0

    late = 0

    submitted = 0



    # Checks every student status
    for student in students:


        if student["Status"] == "Missing":

            missing += 1



        elif student["Status"] == "Late":

            late += 1



        else:

            submitted += 1



    # Total number of students
    total = len(students)





    # ======================================================
    # STATISTIC CARDS
    # ======================================================


    cards = tk.Frame(

        content_frame,

        bg=COLORS["background"]

    )


    cards.pack(

        pady=20

    )



    # Information displayed on cards
    statistics = [

        ("Total Students", total),

        ("Missing", missing),

        ("Late", late),

        ("Submitted", submitted)

    ]
    # Creates each card
    for title, number in statistics:


        card = tk.Frame(

            cards,

            bg=COLORS["white"],

            bd=2,

            relief="ridge",

            width=180,

            height=100

        )



        card.pack(

            side="left",

            padx=15

        )
        # Prevents the card resizing
        card.pack_propagate(False)



        # Card heading
        tk.Label(

            card,

            text=title,

            font=FONT_NORMAL,

            bg=COLORS["white"]

        ).pack()



        # Large number display
        tk.Label(

            card,

            text=str(number),

            font=(

                "Segoe UI",

                25,

                "bold"

            ),

            fg=COLORS["primary"],

            bg=COLORS["white"]

        ).pack()

    # ======================================================
    # STUDENTS NEEDING ATTENTION
    # ======================================================


    tk.Label(

        content_frame,

        text="Students Requiring Attention",

        font=FONT_HEADER,

        bg=COLORS["background"]

    ).pack(

        pady=15

    )
    # Text box for students needing work updates
    attention = tk.Text(

        content_frame,

        height=10,

        width=70

    )


    attention.pack()



    found = False



    # Searches for incomplete work
    for student in students:


        if student["Status"] != "Submitted":


            found = True



            attention.insert(

                tk.END,

                f"{student['Name']} - "

                f"{student['Class']} - "

                f"{student['Status']}\n"

            )



    # Message if everything is complete
    if not found:


        attention.insert(

            tk.END,

            "All students have submitted work."

        )



    # Prevents editing report information
    attention.config(

        state="disabled"

    )
# ==========================================================
# APPLICATION CLOSE
# ==========================================================


def close_program():

    """
    Saves data before closing
    the application.
    """
    # Saves current information
    save_data()
    # Closes window
    window.destroy()
# ==========================================================
# WINDOW CLOSE EVENT
# ==========================================================
# Runs close_program when user presses X
window.protocol(

    "WM_DELETE_WINDOW",

    close_program

)

# ==========================================================
# START APPLICATION
# ==========================================================


# Opens login screen when program starts
login_screen()



# Keeps application running
window.mainloop()